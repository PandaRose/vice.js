#!/bin/sh

rm -rf bin libs obj gen
